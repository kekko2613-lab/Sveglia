# Sveglia 2.0 – sveglia in stile iPhone per Android

Novità: volume graduale, timer, cronometro, "scuoti per fermare", colore principale a scelta
e sfondo dalla galleria. Android 8.0 o superiore.

## Aggiornare l'app su GitHub
1. Nel repository tocca + > Upload files e carica di nuovo Sveglia-Android.zip
   (stesso nome: sostituisce il vecchio). Commit changes.
2. Attendi il segno verde in Actions e scarica Sveglia-apk.
3. Prima volta con questa versione: disinstalla la vecchia app (la chiave di firma è cambiata),
   poi installa il nuovo APK. Dagli aggiornamenti successivi si installa sopra senza perdere nulla.
