package com.sveglia.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val ACCENTS = listOf(
    Color(0xFFFF9F0A), Color(0xFF0A84FF), Color(0xFFFF375F),
    Color(0xFFBF5AF2), Color(0xFF30D158), Color(0xFF64D2FF)
)

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch { Theme.setBackground(ctx, uri) }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text(
            "Impostazioni", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)
        )

        Column(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                .clip(RoundedCornerShape(12.dp)).background(CardBg).padding(16.dp)
        ) {
            Text("Colore principale", color = Color.White, fontSize = 17.sp)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ACCENTS.forEach { c ->
                    val sel = c == Theme.accent
                    Box(
                        Modifier.size(42.dp).clip(CircleShape).background(c)
                            .border(if (sel) 3.dp else 0.dp, Color.White, CircleShape)
                            .clickable { Theme.saveAccent(ctx, c) }
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Column(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                .clip(RoundedCornerShape(12.dp)).background(CardBg)
        ) {
            Row(
                Modifier.fillMaxWidth().clickable {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }.padding(16.dp)
            ) {
                Text("Scegli sfondo dalla galleria", color = Orange, fontSize = 17.sp)
            }
            if (Theme.bgImage != null) {
                Hairline()
                Row(
                    Modifier.fillMaxWidth().clickable { Theme.clearBackground(ctx) }.padding(16.dp)
                ) {
                    Text("Rimuovi sfondo", color = Red, fontSize = 17.sp)
                }
                Hairline()
                Column(Modifier.padding(16.dp)) {
                    Text("Oscuramento sfondo", color = Color.White, fontSize = 17.sp)
                    Slider(
                        value = Theme.dim,
                        onValueChange = { Theme.dim = it },
                        onValueChangeFinished = { Theme.saveDim(ctx) },
                        valueRange = 0f..0.85f,
                        colors = SliderDefaults.colors(
                            thumbColor = Orange, activeTrackColor = Orange
                        )
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Text(
            "Lo sfondo vale per tutta l'app e per la schermata della sveglia.",
            color = Gray, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 24.dp)
        )
        Spacer(Modifier.height(32.dp))
    }
}
