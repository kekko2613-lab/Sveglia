package com.sveglia.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/** Impostazioni grafiche: colore principale, sfondo dalla galleria, oscuramento. */
object Theme {
    var accent by mutableStateOf(Color(0xFFFF9F0A))
    var bgImage by mutableStateOf<ImageBitmap?>(null)
    var dim by mutableFloatStateOf(0.45f)

    private fun prefs(c: Context) =
        c.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private fun bgFile(c: Context) = File(c.applicationContext.filesDir, "background.jpg")

    fun load(c: Context) {
        val p = prefs(c)
        accent = Color(p.getInt("accent", Color(0xFFFF9F0A).toArgb()))
        dim = p.getFloat("dim", 0.45f)
        bgImage = try {
            bgFile(c).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path)?.asImageBitmap() }
        } catch (e: Exception) {
            null
        }
    }

    fun saveAccent(c: Context, color: Color) {
        accent = color
        prefs(c).edit().putInt("accent", color.toArgb()).apply()
    }

    fun saveDim(c: Context) {
        prefs(c).edit().putFloat("dim", dim).apply()
    }

    fun clearBackground(c: Context) {
        bgFile(c).delete()
        bgImage = null
    }

    /** Copia l'immagine scelta nella memoria dell'app (ridimensionata) e la imposta come sfondo. */
    suspend fun setBackground(c: Context, uri: Uri): Boolean {
        val bmp = withContext(Dispatchers.IO) {
            val b = decode(c, uri) ?: return@withContext null
            try {
                FileOutputStream(bgFile(c)).use { b.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                b
            } catch (e: Exception) {
                null
            }
        } ?: return false
        bgImage = bmp.asImageBitmap()
        return true
    }

    private fun decode(c: Context, uri: Uri): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 28) {
            val src = ImageDecoder.createSource(c.contentResolver, uri)
            ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                val big = maxOf(info.size.width, info.size.height)
                if (big > 2200) dec.setTargetSampleSize(big / 1100)
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2200) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        }
    } catch (e: Exception) {
        null
    }
}

@Composable
fun SvegliaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Theme.accent,
            background = Color.Black,
            surface = CardBg,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

/** Sfondo nero, oppure l'immagine scelta con uno strato scuro sopra per leggere bene i testi. */
@Composable
fun AppBackground(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        val img = Theme.bgImage
        if (img != null) {
            Image(
                bitmap = img,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = Theme.dim)))
        }
        content()
    }
}
