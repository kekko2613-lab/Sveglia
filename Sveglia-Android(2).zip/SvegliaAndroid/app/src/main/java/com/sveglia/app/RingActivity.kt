package com.sveglia.app

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sqrt

class RingActivity : ComponentActivity(), SensorEventListener {

    private val shakes = mutableIntStateOf(0)
    private var lastShake = 0L
    private var alarmId = -1
    private var needShake = false
    private var sensorManager: SensorManager? = null

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        Theme.load(this)
        alarmId = intent.getIntExtra(EXTRA_ID, -1)
        val alarm = resolveAlarm(this, alarmId)
        needShake = alarm?.shake == true
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        setContent {
            SvegliaTheme {
                AppBackground {
                    RingScreen(
                        alarm = alarm,
                        shakes = shakes.intValue,
                        onStop = { send(ACTION_STOP); finish() },
                        onSnooze = { send(ACTION_SNOOZE); finish() }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (needShake) {
            val s = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (s != null) sensorManager?.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager?.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (!needShake) return
        val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
        val t = SystemClock.elapsedRealtime()
        if (g > 20f && t - lastShake > 250) {
            lastShake = t
            shakes.intValue = shakes.intValue + 1
            if (shakes.intValue >= SHAKES_NEEDED) {
                send(ACTION_STOP)
                finish()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun send(action: String) {
        startService(
            Intent(this, AlarmService::class.java).setAction(action).putExtra(EXTRA_ID, alarmId)
        )
    }
}

@Composable
private fun RingScreen(alarm: Alarm?, shakes: Int, onStop: () -> Unit, onSnooze: () -> Unit) {
    val isTimer = alarm?.id == TIMER_ID
    val shakeMode = alarm?.shake == true
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 80.dp)) {
            Text(alarm?.label ?: "Sveglia", color = Gray, fontSize = 22.sp)
            Text(
                alarm?.timeText() ?: "",
                color = Color.White,
                fontSize = if (isTimer) 44.sp else 88.sp,
                fontWeight = FontWeight.Light
            )
        }
        Column(Modifier.padding(bottom = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (shakeMode) {
                Text(
                    "Scuoti il telefono per fermare la sveglia",
                    color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(14.dp))
                Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(CardBg2)) {
                    Box(
                        Modifier.fillMaxWidth(
                            (shakes.toFloat() / SHAKES_NEEDED).coerceIn(0.02f, 1f)
                        ).height(10.dp).clip(RoundedCornerShape(5.dp)).background(Orange)
                    )
                }
                Spacer(Modifier.height(24.dp))
            }
            if (alarm?.snooze == true) {
                Box(
                    Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(32.dp))
                        .background(CardBg2).clickable(onClick = onSnooze),
                    contentAlignment = Alignment.Center
                ) { Text("Posticipa", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium) }
                Spacer(Modifier.height(16.dp))
            }
            if (!shakeMode) {
                Box(
                    Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(32.dp))
                        .background(Orange).clickable(onClick = onStop),
                    contentAlignment = Alignment.Center
                ) { Text("Stop", color = Color.Black, fontSize = 20.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
    }
}
