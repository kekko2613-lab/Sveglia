package com.sveglia.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class AlarmService : Service() {

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var volume = 1f
    private val ramp = object : Runnable {
        override fun run() {
            volume = (volume + 0.035f).coerceAtMost(1f)
            player?.setVolume(volume, volume)
            if (volume < 1f) handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getIntExtra(EXTRA_ID, -1) ?: -1
        when (intent?.action) {
            ACTION_STOP -> {
                shutdown()
                return START_NOT_STICKY
            }
            ACTION_SNOOZE -> {
                if (id >= 0) AlarmScheduler.snooze(this, id)
                shutdown()
                return START_NOT_STICKY
            }
        }

        val alarm = resolveAlarm(this, id)
        ServiceCompat.startForeground(
            this, 1, buildNotification(id, alarm),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        )
        handler.removeCallbacksAndMessages(null)
        startRinging(alarm)
        handler.postDelayed({ shutdown() }, 10 * 60 * 1000L) // si ferma da sola dopo 10 minuti
        return START_NOT_STICKY
    }

    private fun buildNotification(id: Int, alarm: Alarm?): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(CHANNEL_ID, "Sveglia", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(ch)
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val ring = Intent(this, RingActivity::class.java)
            .putExtra(EXTRA_ID, id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val full = PendingIntent.getActivity(this, 0, ring, flags)
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, AlarmService::class.java).setAction(ACTION_STOP), flags
        )
        val snoozePi = PendingIntent.getService(
            this, 2,
            Intent(this, AlarmService::class.java).setAction(ACTION_SNOOZE).putExtra(EXTRA_ID, id),
            flags
        )
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(alarm?.label ?: "Sveglia")
            .setContentText(alarm?.timeText() ?: "")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setFullScreenIntent(full, true)
            .setContentIntent(full)
        // Con "scuoti per fermare" il pulsante Stop nella notifica non c'è
        if (alarm?.shake != true) b.addAction(0, "Stop", stopPi)
        if (alarm?.snooze == true) b.addAction(0, "Posticipa", snoozePi)
        return b.build()
    }

    private fun tryPlay(uri: Uri?): Boolean {
        if (uri == null) return false
        return try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
            true
        } catch (e: Exception) {
            false
        }
    }

    @Suppress("DEPRECATION")
    private fun startRinging(alarm: Alarm?) {
        stopRinging()
        val custom = alarm?.soundUri?.takeIf { it.isNotEmpty() }?.let { Uri.parse(it) }
        val ok = tryPlay(custom)
                || tryPlay(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                || tryPlay(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
        if (ok) {
            if (alarm?.gradual == true) {
                volume = 0.05f
                player?.setVolume(volume, volume)
                handler.postDelayed(ramp, 1000)
            } else {
                volume = 1f
                player?.setVolume(1f, 1f)
            }
        }

        val v = if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        vibrator = v
        v.vibrate(
            VibrationEffect.createWaveform(longArrayOf(0, 700, 600), 0),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
        )
    }

    private fun stopRinging() {
        handler.removeCallbacks(ramp)
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        player?.release()
        player = null
        vibrator?.cancel()
        vibrator = null
    }

    private fun shutdown() {
        handler.removeCallbacksAndMessages(null)
        stopRinging()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopRinging()
        super.onDestroy()
    }
}
