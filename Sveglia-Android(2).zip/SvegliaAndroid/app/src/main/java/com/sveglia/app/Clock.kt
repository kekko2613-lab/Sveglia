package com.sveglia.app

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ---------------------------------------------------------------- Timer: dati

object TimerStore {
    data class State(val durationMs: Long, val endMs: Long, val remainingMs: Long)

    private fun p(c: Context) = c.applicationContext.getSharedPreferences("timer", Context.MODE_PRIVATE)

    fun load(c: Context): State {
        val p = p(c)
        return State(p.getLong("duration", 0L), p.getLong("end", 0L), p.getLong("remaining", 0L))
    }

    private fun save(c: Context, s: State) {
        p(c).edit().putLong("duration", s.durationMs).putLong("end", s.endMs)
            .putLong("remaining", s.remainingMs).apply()
    }

    fun start(c: Context, durationMs: Long) {
        val end = System.currentTimeMillis() + durationMs
        save(c, State(durationMs, end, 0L))
        AlarmScheduler.scheduleTimer(c, end)
    }

    fun pause(c: Context) {
        val s = load(c)
        val rem = (s.endMs - System.currentTimeMillis()).coerceAtLeast(1000L)
        save(c, State(s.durationMs, 0L, rem))
        AlarmScheduler.cancelTimer(c)
    }

    fun resume(c: Context) {
        val s = load(c)
        val end = System.currentTimeMillis() + s.remainingMs
        save(c, State(s.durationMs, end, 0L))
        AlarmScheduler.scheduleTimer(c, end)
    }

    /** Azzera lo stato senza toccare l'allarme (usato quando il timer è già scaduto). */
    fun clear(c: Context) = save(c, State(load(c).durationMs, 0L, 0L))

    fun cancel(c: Context) {
        clear(c)
        AlarmScheduler.cancelTimer(c)
    }
}

// ---------------------------------------------------------------- Cronometro: dati

object StopwatchStore {
    data class State(val running: Boolean, val startedAt: Long, val acc: Long, val laps: List<Long>)

    private fun p(c: Context) = c.applicationContext.getSharedPreferences("stopwatch", Context.MODE_PRIVATE)

    fun load(c: Context): State {
        val p = p(c)
        val laps = (p.getString("laps", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }
        return State(p.getBoolean("running", false), p.getLong("startedAt", 0L), p.getLong("acc", 0L), laps)
    }

    fun save(c: Context, s: State) {
        p(c).edit().putBoolean("running", s.running).putLong("startedAt", s.startedAt)
            .putLong("acc", s.acc).putString("laps", s.laps.joinToString(",")).apply()
    }
}

// ---------------------------------------------------------------- Componenti comuni

@Composable
fun CircleButton(text: String, tint: Color, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.size(92.dp).alpha(if (enabled) 1f else 0.4f).clip(CircleShape)
            .background(tint.copy(alpha = 0.25f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = tint, fontSize = 17.sp, fontWeight = FontWeight.Medium)
    }
}

private fun fmtCountdown(ms: Long): String {
    val total = (ms + 999) / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

private fun fmtCs(ms: Long): String =
    "%02d:%02d,%02d".format(ms / 60000, (ms / 1000) % 60, (ms % 1000) / 10)

// ---------------------------------------------------------------- Timer

@Composable
fun TimerScreen() {
    val ctx = LocalContext.current
    var state by remember { mutableStateOf(TimerStore.load(ctx)) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var h by remember { mutableIntStateOf(0) }
    var m by remember { mutableIntStateOf(1) }
    var s by remember { mutableIntStateOf(0) }

    LaunchedEffect(state.endMs) {
        while (state.endMs > 0L) {
            now = System.currentTimeMillis()
            if (now >= state.endMs) {
                TimerStore.clear(ctx)
                state = TimerStore.load(ctx)
                break
            }
            delay(200)
        }
    }

    val running = state.endMs > 0L
    val paused = !running && state.remainingMs > 0L

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "Timer", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)
        )
        Spacer(Modifier.height(24.dp))

        if (running || paused) {
            val remaining = if (running) (state.endMs - now).coerceAtLeast(0L) else state.remainingMs
            Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) {
                Text(
                    fmtCountdown(remaining),
                    style = TextStyle(
                        color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Light,
                        fontFeatureSettings = "tnum"
                    )
                )
            }
        } else {
            Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) {
                WheelBar()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Wheel(24, h, { h = it }, Modifier.width(64.dp))
                    Text("ore", color = Gray, fontSize = 14.sp)
                    Wheel(60, m, { m = it }, Modifier.width(64.dp))
                    Text("min", color = Gray, fontSize = 14.sp)
                    Wheel(60, s, { s = it }, Modifier.width(64.dp))
                    Text("sec", color = Gray, fontSize = 14.sp)
                }
            }
        }

        Spacer(Modifier.height(32.dp))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 32.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            CircleButton("Annulla", Gray, enabled = running || paused) {
                TimerStore.cancel(ctx)
                state = TimerStore.load(ctx)
            }
            when {
                running -> CircleButton("Pausa", Orange) {
                    TimerStore.pause(ctx); state = TimerStore.load(ctx)
                }
                paused -> CircleButton("Riprendi", Green) {
                    TimerStore.resume(ctx); state = TimerStore.load(ctx)
                }
                else -> CircleButton("Avvia", Green, enabled = (h + m + s) > 0) {
                    TimerStore.start(ctx, ((h * 3600L) + (m * 60L) + s) * 1000L)
                    state = TimerStore.load(ctx)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Cronometro

@Composable
fun StopwatchScreen() {
    val ctx = LocalContext.current
    val saved = remember { StopwatchStore.load(ctx) }
    var running by remember { mutableStateOf(saved.running) }
    var startedAt by remember { mutableLongStateOf(saved.startedAt) }
    var acc by remember { mutableLongStateOf(saved.acc) }
    val laps = remember { mutableStateListOf<Long>().apply { addAll(saved.laps) } }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(running) {
        while (running) {
            now = System.currentTimeMillis()
            delay(30)
        }
    }
    val elapsed = acc + if (running) (now - startedAt).coerceAtLeast(0L) else 0L

    fun persist() = StopwatchStore.save(ctx, StopwatchStore.State(running, startedAt, acc, laps.toList()))

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "Cronometro", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)
        )
        Box(Modifier.fillMaxWidth().height(170.dp), contentAlignment = Alignment.Center) {
            Text(
                fmtCs(elapsed),
                style = TextStyle(
                    color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light,
                    fontFeatureSettings = "tnum"
                )
            )
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 32.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            if (running) {
                CircleButton("Giro", Gray) {
                    laps.add(System.currentTimeMillis().let { acc + (it - startedAt) })
                    persist()
                }
            } else {
                CircleButton("Azzera", Gray, enabled = elapsed > 0L) {
                    acc = 0L; laps.clear(); persist()
                }
            }
            if (running) {
                CircleButton("Stop", Red) {
                    val t = System.currentTimeMillis()
                    acc += (t - startedAt).coerceAtLeast(0L)
                    running = false
                    persist()
                }
            } else {
                CircleButton("Avvia", Green) {
                    startedAt = System.currentTimeMillis()
                    now = startedAt
                    running = true
                    persist()
                }
            }
        }
        Spacer(Modifier.height(24.dp))
        LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
            items(laps.indices.reversed().toList()) { i ->
                val lapMs = laps[i] - (if (i > 0) laps[i - 1] else 0L)
                Column {
                    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
                        Text("Giro ${i + 1}", color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                        Text(fmtCs(lapMs), color = Color.White, fontSize = 17.sp)
                    }
                    Hairline()
                }
            }
        }
    }
}
