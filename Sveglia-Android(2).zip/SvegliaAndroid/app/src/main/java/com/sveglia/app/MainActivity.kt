package com.sveglia.app

import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var store: AlarmStore
    private val alarms = mutableStateListOf<Alarm>()

    private fun reload() {
        alarms.clear()
        alarms.addAll(store.load().sortedBy { it.hour * 60 + it.minute })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashLogger()
        store = AlarmStore(this)
        Theme.load(this)
        reload()
        setContent {
            SvegliaTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.Transparent) {
                    AppBackground { App() }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    /** Se l'app va in crash, salva l'errore e lo mostra al prossimo avvio. */
    private fun installCrashLogger() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                getSharedPreferences("crash", MODE_PRIVATE).edit()
                    .putString("trace", Log.getStackTraceString(e)).commit()
            } catch (_: Exception) {
            }
            prev?.uncaughtException(t, e)
        }
    }

    @Composable
    private fun App() {
        var crash by remember {
            mutableStateOf(getSharedPreferences("crash", MODE_PRIVATE).getString("trace", null))
        }
        crash?.let { trace ->
            val close = {
                getSharedPreferences("crash", MODE_PRIVATE).edit().remove("trace").apply()
                crash = null
            }
            AlertDialog(
                onDismissRequest = close,
                containerColor = Color(0xFF1C1C1E),
                title = { Text("Errore dell'ultima volta", color = Color.White) },
                text = { Text(trace.take(1200), color = Color.White, fontSize = 10.sp) },
                confirmButton = { TextButton(onClick = close) { Text("Chiudi", color = Orange) } }
            )
        }
        var tab by remember { mutableIntStateOf(0) }
        var editing by remember { mutableStateOf<Alarm?>(null) }
        var isNew by remember { mutableStateOf(false) }

        val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(
                    this@MainActivity, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        BackHandler(enabled = editing != null) { editing = null }

        val e = editing
        if (e != null) {
            EditAlarmScreen(
                initial = e,
                isNew = isNew,
                onCancel = { editing = null },
                onSave = { saveAlarm(it); editing = null },
                onDelete = { deleteAlarm(e); editing = null }
            )
        } else {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        0 -> AlarmListScreen(
                            alarms = alarms,
                            onAdd = { isNew = true; editing = Alarm(Alarm.newId(), 7, 0) },
                            onOpen = { isNew = false; editing = it },
                            onToggle = { a, on -> saveAlarm(a.copy(enabled = on)) }
                        )
                        1 -> TimerScreen()
                        2 -> StopwatchScreen()
                        else -> SettingsScreen()
                    }
                }
                BottomBar(tab) { tab = it }
            }
        }
    }

    private fun saveAlarm(a: Alarm) {
        try {
            store.upsert(a)
            if (a.enabled) {
                if (AlarmScheduler.schedule(this, a)) {
                    toastNext(a)
                } else {
                    Toast.makeText(
                        this, "Consenti \"Sveglie e promemoria\" per questa app", Toast.LENGTH_LONG
                    ).show()
                    if (Build.VERSION.SDK_INT >= 31) {
                        try {
                            startActivity(
                                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                            )
                        } catch (_: Exception) {
                        }
                    }
                }
            } else {
                AlarmScheduler.cancel(this, a)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Errore: $e", Toast.LENGTH_LONG).show()
        }
        reload()
    }

    private fun deleteAlarm(a: Alarm) {
        AlarmScheduler.cancel(this, a)
        store.delete(a.id)
        reload()
    }

    private fun toastNext(a: Alarm) {
        val totalMin = ((AlarmScheduler.nextTrigger(a) - System.currentTimeMillis()) / 60_000L).toInt() + 1
        val d = totalMin / (60 * 24)
        val h = (totalMin / 60) % 24
        val m = totalMin % 60
        val parts = mutableListOf<String>()
        if (d > 0) parts.add(if (d == 1) "1 giorno" else "$d giorni")
        if (h > 0) parts.add(if (h == 1) "1 ora" else "$h ore")
        if (m > 0 && d == 0) parts.add(if (m == 1) "1 minuto" else "$m minuti")
        Toast.makeText(this, "Suona tra " + parts.joinToString(" e "), Toast.LENGTH_SHORT).show()
    }
}
