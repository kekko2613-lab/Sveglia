package com.sveglia.app

import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.IntentCompat
import java.util.Calendar

val Orange = Color(0xFFFF9F0A)
val Green = Color(0xFF30D158)
val CardBg = Color(0xFF1C1C1E)
val CardBg2 = Color(0xFF2C2C2E)
val Gray = Color(0xFF8E8E93)
val Red = Color(0xFFFF453A)

// Ordine italiano: Lun..Dom, con le costanti di Calendar
val DAY_ORDER = listOf(
    Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY,
    Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY
)
val DAY_LETTERS = listOf("L", "M", "M", "G", "V", "S", "D")
val DAY_NAMES = listOf("Lun", "Mar", "Mer", "Gio", "Ven", "Sab", "Dom")

fun daysSummary(days: Set<Int>): String {
    if (days.isEmpty()) return "Una volta"
    if (days.size == 7) return "Ogni giorno"
    val weekdays = setOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY)
    if (days == weekdays) return "Giorni feriali"
    if (days == setOf(Calendar.SATURDAY, Calendar.SUNDAY)) return "Weekend"
    return DAY_ORDER.filter { it in days }.joinToString(" ") { DAY_NAMES[DAY_ORDER.indexOf(it)] }
}

@Composable
fun SvegliaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Orange,
            background = Color.Black,
            surface = CardBg,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

// ---------------------------------------------------------------- Elenco

@Composable
fun AlarmListScreen(
    alarms: List<Alarm>,
    onAdd: () -> Unit,
    onOpen: (Alarm) -> Unit,
    onToggle: (Alarm, Boolean) -> Unit
) {
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Sveglia", color = Color.White, fontSize = 34.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
            )
            Text(
                "+", color = Orange, fontSize = 40.sp,
                modifier = Modifier.clickable(onClick = onAdd).padding(horizontal = 12.dp)
            )
        }
        if (alarms.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Nessuna sveglia", color = Gray, fontSize = 18.sp)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(alarms, key = { it.id }) { a -> AlarmRow(a, onOpen, onToggle) }
            }
        }
    }
}

@Composable
private fun AlarmRow(a: Alarm, onOpen: (Alarm) -> Unit, onToggle: (Alarm, Boolean) -> Unit) {
    val textColor = if (a.enabled) Color.White else Gray
    Column {
        Row(
            Modifier.fillMaxWidth()
                .clickable { onOpen(a) }
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(a.timeText(), color = textColor, fontSize = 54.sp, fontWeight = FontWeight.Light)
                Text(
                    "${a.label}, ${daysSummary(a.days)}",
                    color = textColor, fontSize = 15.sp
                )
            }
            Switch(
                checked = a.enabled,
                onCheckedChange = { onToggle(a, it) },
                colors = SwitchDefaults.colors(
                    checkedTrackColor = Green,
                    checkedThumbColor = Color.White,
                    checkedBorderColor = Color.Transparent,
                    uncheckedTrackColor = CardBg2,
                    uncheckedThumbColor = Color.White,
                    uncheckedBorderColor = Color.Transparent
                )
            )
        }
        Box(
            Modifier.fillMaxWidth().padding(start = 20.dp).height(0.5.dp).background(CardBg2)
        )
    }
}

// ---------------------------------------------------------------- Modifica

@Composable
fun EditAlarmScreen(
    initial: Alarm,
    isNew: Boolean,
    onCancel: () -> Unit,
    onSave: (Alarm) -> Unit,
    onDelete: () -> Unit
) {
    val ctx = LocalContext.current
    var hour by remember { mutableIntStateOf(initial.hour) }
    var minute by remember { mutableIntStateOf(initial.minute) }
    var days by remember { mutableStateOf(initial.days) }
    var label by remember { mutableStateOf(initial.label) }
    var snooze by remember { mutableStateOf(initial.snooze) }
    var sound by remember { mutableStateOf(initial.soundUri) }

    val soundLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val uri = r.data?.let {
                IntentCompat.getParcelableExtra(it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            }
            sound = uri?.toString() ?: ""
        }
    }
    val soundName = remember(sound) {
        if (sound.isEmpty()) "Predefinita" else try {
            RingtoneManager.getRingtone(ctx, Uri.parse(sound))?.getTitle(ctx) ?: "Personalizzata"
        } catch (e: Exception) {
            "Personalizzata"
        }
    }

    Column(
        Modifier.fillMaxSize().background(Color.Black).verticalScroll(rememberScrollState())
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Annulla", color = Orange, fontSize = 17.sp, modifier = Modifier.clickable(onClick = onCancel))
            Text(
                if (isNew) "Aggiungi sveglia" else "Modifica sveglia",
                color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
            )
            Text(
                "Salva", color = Orange, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable {
                    onSave(
                        Alarm(
                            id = initial.id, hour = hour, minute = minute, days = days,
                            label = label.ifBlank { "Sveglia" }, enabled = true,
                            snooze = snooze, soundUri = sound
                        )
                    )
                }
            )
        }

        TimeWheels(hour, minute, { hour = it }, { minute = it })

        Spacer(Modifier.height(16.dp))

        Column(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                .clip(RoundedCornerShape(12.dp)).background(CardBg)
        ) {
            // Ripeti
            Column(Modifier.padding(16.dp)) {
                Text("Ripeti", color = Color.White, fontSize = 17.sp)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    DAY_ORDER.forEachIndexed { i, d ->
                        val sel = d in days
                        Box(
                            Modifier.size(40.dp).clip(CircleShape)
                                .background(if (sel) Orange else CardBg2)
                                .clickable { days = if (sel) days - d else days + d },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                DAY_LETTERS[i],
                                color = if (sel) Color.Black else Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
            Divider()
            // Etichetta
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Etichetta", color = Color.White, fontSize = 17.sp)
                BasicTextField(
                    value = label,
                    onValueChange = { label = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Gray, fontSize = 17.sp, textAlign = TextAlign.End),
                    cursorBrush = SolidColor(Orange),
                    modifier = Modifier.weight(1f).padding(start = 16.dp)
                )
            }
            Divider()
            // Suono
            Row(
                Modifier.fillMaxWidth().clickable {
                    val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                        if (sound.isNotEmpty()) putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(sound))
                    }
                    soundLauncher.launch(i)
                }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Suono", color = Color.White, fontSize = 17.sp)
                Text(
                    soundName, color = Gray, fontSize = 17.sp, textAlign = TextAlign.End,
                    maxLines = 1, modifier = Modifier.weight(1f).padding(start = 16.dp)
                )
            }
            Divider()
            // Posticipa
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Posticipa", color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Switch(
                    checked = snooze, onCheckedChange = { snooze = it },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = Green, checkedThumbColor = Color.White,
                        checkedBorderColor = Color.Transparent,
                        uncheckedTrackColor = CardBg2, uncheckedThumbColor = Color.White,
                        uncheckedBorderColor = Color.Transparent
                    )
                )
            }
        }

        if (!isNew) {
            Spacer(Modifier.height(16.dp))
            Box(
                Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp)).background(CardBg)
                    .clickable(onClick = onDelete).padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Elimina sveglia", color = Red, fontSize = 17.sp)
            }
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun Divider() {
    Box(Modifier.fillMaxWidth().padding(start = 16.dp).height(0.5.dp).background(CardBg2))
}

// ---------------------------------------------------------------- Rotelle ora

@Composable
private fun TimeWheels(hour: Int, minute: Int, onHour: (Int) -> Unit, onMinute: (Int) -> Unit) {
    val itemH = 44.dp
    Box(
        Modifier.fillMaxWidth().height(itemH * 5),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.padding(horizontal = 32.dp).fillMaxWidth().height(itemH)
                .clip(RoundedCornerShape(10.dp)).background(CardBg2)
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Wheel(24, hour, onHour, Modifier.width(90.dp))
            Text(":", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Medium)
            Wheel(60, minute, onMinute, Modifier.width(90.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Wheel(count: Int, initial: Int, onSelected: (Int) -> Unit, modifier: Modifier = Modifier) {
    val itemH = 44.dp
    val itemPx = with(LocalDensity.current) { itemH.toPx() }
    val state = rememberLazyListState(initialFirstVisibleItemIndex = initial)
    val fling = rememberSnapFlingBehavior(lazyListState = state)
    val selected by remember {
        derivedStateOf {
            val extra = if (state.firstVisibleItemScrollOffset > itemPx / 2) 1 else 0
            (state.firstVisibleItemIndex + extra).coerceIn(0, count - 1)
        }
    }
    LaunchedEffect(selected) { onSelected(selected) }

    LazyColumn(
        state = state,
        flingBehavior = fling,
        modifier = modifier.height(itemH * 5),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 2 elementi vuoti sopra e sotto: il valore al centro è quello selezionato
        items(2) { Spacer(Modifier.height(itemH)) }
        items(count) { i ->
            Box(Modifier.height(itemH).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    "%02d".format(i),
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (i == selected) Color.White else Gray
                )
            }
        }
        items(2) { Spacer(Modifier.height(itemH)) }
    }
}
