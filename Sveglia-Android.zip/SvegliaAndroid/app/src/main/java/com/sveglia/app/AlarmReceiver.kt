package com.sveglia.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(EXTRA_ID, -1)
        val isSnooze = intent.getBooleanExtra(EXTRA_SNOOZE, false)
        val store = AlarmStore(context)
        val alarm = store.load().find { it.id == id } ?: return

        if (!isSnooze) {
            if (alarm.days.isEmpty()) {
                // Sveglia singola: si spegne dopo aver suonato
                store.upsert(alarm.copy(enabled = false))
            } else {
                // Sveglia ripetuta: pianifica la prossima
                AlarmScheduler.schedule(context, alarm)
            }
        }

        val svc = Intent(context, AlarmService::class.java).putExtra(EXTRA_ID, id)
        ContextCompat.startForegroundService(context, svc)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmScheduler.rescheduleAll(context)
    }
}
