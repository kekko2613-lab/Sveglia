package com.sveglia.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var store: AlarmStore
    private val alarms = mutableStateListOf<Alarm>()

    private fun reload() {
        alarms.clear()
        alarms.addAll(store.load().sortedBy { it.hour * 60 + it.minute })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = AlarmStore(this)
        reload()
        setContent {
            SvegliaTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) { App() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    @Composable
    private fun App() {
        var editing by remember { mutableStateOf<Alarm?>(null) }
        var isNew by remember { mutableStateOf(false) }

        val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(
                    this@MainActivity, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        BackHandler(enabled = editing != null) { editing = null }

        val e = editing
        if (e == null) {
            AlarmListScreen(
                alarms = alarms,
                onAdd = { isNew = true; editing = Alarm(Alarm.newId(), 7, 0) },
                onOpen = { isNew = false; editing = it },
                onToggle = { a, on -> saveAlarm(a.copy(enabled = on)) }
            )
        } else {
            EditAlarmScreen(
                initial = e,
                isNew = isNew,
                onCancel = { editing = null },
                onSave = { saveAlarm(it); editing = null },
                onDelete = { deleteAlarm(e); editing = null }
            )
        }
    }

    private fun saveAlarm(a: Alarm) {
        store.upsert(a)
        if (a.enabled) {
            AlarmScheduler.schedule(this, a)
            toastNext(a)
        } else {
            AlarmScheduler.cancel(this, a)
        }
        reload()
    }

    private fun deleteAlarm(a: Alarm) {
        AlarmScheduler.cancel(this, a)
        store.delete(a.id)
        reload()
    }

    private fun toastNext(a: Alarm) {
        val totalMin = ((AlarmScheduler.nextTrigger(a) - System.currentTimeMillis()) / 60_000L).toInt() + 1
        val d = totalMin / (60 * 24)
        val h = (totalMin / 60) % 24
        val m = totalMin % 60
        val parts = mutableListOf<String>()
        if (d > 0) parts.add(if (d == 1) "1 giorno" else "$d giorni")
        if (h > 0) parts.add(if (h == 1) "1 ora" else "$h ore")
        if (m > 0 && d == 0) parts.add(if (m == 1) "1 minuto" else "$m minuti")
        Toast.makeText(this, "Suona tra " + parts.joinToString(" e "), Toast.LENGTH_SHORT).show()
    }
}
