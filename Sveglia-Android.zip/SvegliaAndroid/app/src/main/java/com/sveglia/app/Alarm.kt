package com.sveglia.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

const val EXTRA_ID = "alarm_id"
const val EXTRA_SNOOZE = "alarm_snooze"
const val ACTION_STOP = "com.sveglia.app.STOP"
const val ACTION_SNOOZE = "com.sveglia.app.SNOOZE"
const val CHANNEL_ID = "sveglia_channel"
const val SNOOZE_MINUTES = 9

/** days usa le costanti di java.util.Calendar (DOMENICA=1 ... SABATO=7). Vuoto = una sola volta. */
data class Alarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val days: Set<Int> = emptySet(),
    val label: String = "Sveglia",
    val enabled: Boolean = true,
    val snooze: Boolean = true,
    val soundUri: String = ""
) {
    fun timeText(): String = "%02d:%02d".format(hour, minute)

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("hour", hour)
        put("minute", minute)
        put("days", JSONArray(days.toList()))
        put("label", label)
        put("enabled", enabled)
        put("snooze", snooze)
        put("sound", soundUri)
    }

    companion object {
        fun fromJson(o: JSONObject): Alarm {
            val d = o.optJSONArray("days") ?: JSONArray()
            return Alarm(
                id = o.getInt("id"),
                hour = o.getInt("hour"),
                minute = o.getInt("minute"),
                days = (0 until d.length()).map { d.getInt(it) }.toSet(),
                label = o.optString("label", "Sveglia"),
                enabled = o.optBoolean("enabled", true),
                snooze = o.optBoolean("snooze", true),
                soundUri = o.optString("sound", "")
            )
        }

        fun newId(): Int = (System.currentTimeMillis() % 900_000).toInt() + 1
    }
}

class AlarmStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("alarms", Context.MODE_PRIVATE)

    fun load(): List<Alarm> {
        val raw = prefs.getString("list", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { Alarm.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveAll(list: List<Alarm>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    fun upsert(alarm: Alarm) {
        val list = load().toMutableList()
        val i = list.indexOfFirst { it.id == alarm.id }
        if (i >= 0) list[i] = alarm else list.add(alarm)
        saveAll(list)
    }

    fun delete(id: Int) = saveAll(load().filter { it.id != id })
}
