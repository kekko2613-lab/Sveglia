package com.sveglia.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object AlarmScheduler {

    private fun am(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun fireIntent(c: Context, id: Int, snooze: Boolean): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
            .putExtra(EXTRA_ID, id)
            .putExtra(EXTRA_SNOOZE, snooze)
        val code = if (snooze) id + 1_000_000 else id
        return PendingIntent.getBroadcast(
            c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showIntent(c: Context): PendingIntent = PendingIntent.getActivity(
        c, 0, Intent(c, MainActivity::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    /** Prossimo istante (ms) in cui deve suonare la sveglia. */
    fun nextTrigger(a: Alarm): Long {
        val now = Calendar.getInstance()
        for (offset in 0..7) {
            val c = now.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, offset)
            c.set(Calendar.HOUR_OF_DAY, a.hour)
            c.set(Calendar.MINUTE, a.minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            if (c.timeInMillis <= now.timeInMillis) continue
            if (a.days.isEmpty() || a.days.contains(c.get(Calendar.DAY_OF_WEEK))) return c.timeInMillis
        }
        return now.timeInMillis + 24 * 60 * 60 * 1000L
    }

    fun schedule(c: Context, a: Alarm) {
        am(c).setAlarmClock(
            AlarmManager.AlarmClockInfo(nextTrigger(a), showIntent(c)),
            fireIntent(c, a.id, false)
        )
    }

    fun cancel(c: Context, a: Alarm) {
        am(c).cancel(fireIntent(c, a.id, false))
        am(c).cancel(fireIntent(c, a.id, true))
    }

    fun snooze(c: Context, id: Int) {
        val t = System.currentTimeMillis() + SNOOZE_MINUTES * 60_000L
        am(c).setAlarmClock(AlarmManager.AlarmClockInfo(t, showIntent(c)), fireIntent(c, id, true))
    }

    fun rescheduleAll(c: Context) {
        AlarmStore(c).load().filter { it.enabled }.forEach { schedule(c, it) }
    }
}
