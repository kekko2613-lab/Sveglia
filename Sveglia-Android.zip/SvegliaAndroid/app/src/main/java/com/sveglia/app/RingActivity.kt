package com.sveglia.app

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class RingActivity : ComponentActivity() {

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        val id = intent.getIntExtra(EXTRA_ID, -1)
        val alarm = AlarmStore(this).load().find { it.id == id }

        setContent {
            SvegliaTheme {
                RingScreen(
                    alarm = alarm,
                    onStop = { send(ACTION_STOP, id); finish() },
                    onSnooze = { send(ACTION_SNOOZE, id); finish() }
                )
            }
        }
    }

    private fun send(action: String, id: Int) {
        startService(
            Intent(this, AlarmService::class.java).setAction(action).putExtra(EXTRA_ID, id)
        )
    }
}

@androidx.compose.runtime.Composable
private fun RingScreen(alarm: Alarm?, onStop: () -> Unit, onSnooze: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Color.Black).padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 80.dp)) {
            Text(alarm?.label ?: "Sveglia", color = Gray, fontSize = 22.sp)
            Text(
                alarm?.timeText() ?: "",
                color = Color.White, fontSize = 88.sp, fontWeight = FontWeight.Light
            )
        }
        Column(Modifier.padding(bottom = 40.dp)) {
            if (alarm?.snooze != false) {
                Box(
                    Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(32.dp))
                        .background(CardBg2).clickable(onClick = onSnooze),
                    contentAlignment = Alignment.Center
                ) { Text("Posticipa", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium) }
                Spacer(Modifier.height(16.dp))
            }
            Box(
                Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(32.dp))
                    .background(Orange).clickable(onClick = onStop),
                contentAlignment = Alignment.Center
            ) { Text("Stop", color = Color.Black, fontSize = 20.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}
