# Sveglia – sveglia in stile iPhone per Android

Funzioni: elenco sveglie con interruttore, rotelle per ora e minuti, ripetizione per giorno,
etichetta, suoneria a scelta, posticipa (9 min), schermata a tutto schermo anche con telefono
bloccato, sveglie che sopravvivono al riavvio. Android 8.0 o superiore.

## Opzione A – Android Studio
1. Installa Android Studio e scegli File > Open > cartella del progetto.
2. Attendi la sincronizzazione Gradle, poi Build > Build APK(s)
   (oppure collega il telefono e premi Run).
3. L'APK è in app/build/outputs/apk/.

## Opzione B – Senza installare nulla (GitHub)
1. Crea un repository su github.com e carica tutto il contenuto di questa cartella
   (compresa .github).
2. Vai su Actions > "Build APK" > Run workflow (parte anche da solo a ogni push).
3. A fine build scarica l'artefatto "Sveglia-apk" e installa l'APK sul telefono
   (consenti "Installa app sconosciute").

## Primo avvio
Consenti le notifiche. Su alcuni telefoni (Xiaomi, Huawei, Samsung…) imposta il consumo
batteria dell'app su "Senza restrizioni" per essere certo che suoni sempre.
